<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Berita extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        $this->load->library('user_login');
        $this->load->model('m_berita');
    }
    public function index()
    {
        $this->user_login->cek_login();

        $data = array(
            'title' => 'RTQ Al-Yusro',
            'title2' => 'Data Berita',
            'berita' => $this->m_berita->lists(),
            'isi' => 'admin/berita/v_list'
        );
        $this->load->view('admin/layout/v_wrapper', $data, FALSE);
    }

    public function add()
    {
        $this->user_login->cek_login();

        $this->form_validation->set_rules('judul', 'judul', 'required');
        $this->form_validation->set_rules('isi', 'isi', 'required');
        $this->form_validation->set_rules('tgl_berita', 'tgl_berita', 'required');

        if ($this->form_validation->run() == TRUE) {
            $config['upload_path'] = './foto_berita/';
            $config['allowed_types'] = 'gif|jpg|png';
            $config['max_size'] = 2000;
            $this->upload->initialize($config);

            if (!$this->upload->do_upload('foto')) {
                $data = array(
                    'title' => 'RTQ Al-Yusro',
                    'title2' => 'Tambah Data Berita',
                    'error' => $this->upload->display_errors(),
                    'berita' => $this->m_berita->lists(),
                    'isi' => 'admin/berita/v_add'
                );
                $this->load->view('admin/layout/v_wrapper', $data, FALSE);

            } else {
                $upload_data = array('uploads' => $this->upload->data());
                $config['image_library'] = 'gd2';
                $config['source_image'] = './foto_berita/' . $upload_data['uploads']['file_name'];
                $this->load->library('image_lib', $config);

                $data = array(
                    'judul' => $this->input->post('judul'),
                    'gambar' => $this->input->post('gambar'),
                    'tgl_berita' => $this->input->post('tgl_berita'),
                    'gambar' => $upload_data['uploads']['file_name']
                );

                $this->m_berita->add($data);
                $this->session->set_flashdata('pesan', 'Data Guru Berhasil Di Tambahkan !!');
                redirect('berita');
            }
        }
        $data = array(
            'title' => 'RTQ Al-Yusro',
            'title2' => 'Tambah Data Guru',
            'berita' => $this->m_berita->lists(),
            'isi' => 'admin/berita/v_add'
        );
        $this->load->view('admin/layout/v_wrapper', $data, FALSE);
    }

    public function edit($id)
    {
        $this->user_login->cek_login();

        $this->form_validation->set_rules('nama', 'nama', 'required');
        $this->form_validation->set_rules('tempat_lahir', 'tempat lahir', 'required');
        $this->form_validation->set_rules('tanggal_lahir', 'tanggal lahir', 'required');
        $this->form_validation->set_rules('id_bagian', 'departement', 'required');
        $this->form_validation->set_rules('pendidikan', 'pendidikan', 'required');
        $this->form_validation->set_rules('gender', 'Jenis Kelamin', 'required');

        if ($this->form_validation->run() == TRUE) {
            $config['upload_path'] = './foto_guru/';
            $config['allowed_types'] = 'gif|jpg|png';
            $config['max_size'] = 2000;
            $this->upload->initialize($config);

            if (!$this->upload->do_upload('foto')) {
                $data = array(
                    'title' => 'RTQ Al-Yusro',
                    'title2' => 'Edit Data Guru',
                    'error' => $this->upload->display_errors(),
                    'berita' => $this->m_berita->detail($id),
                    // 'bagian' => $this->m_bagian->lists(),
                    'isi' => 'admin/berita/v_edit'
                );
                $this->load->view('admin/layout/v_wrapper', $data, FALSE);

            } else {
                $upload_data = array('uploads' => $this->upload->data());
                $config['image_library'] = 'gd2';
                $config['source_image'] = './berita/' . $upload_data['uploads']['file_name'];
                $this->load->library('image_lib', $config);


                $berita = $this->m_berita->detail($id);
                if ($berita->foto) {
                    unlink('./foto_berita/' . $berita->foto);
                }

                $data = array(
                    'id' => $id,
                    'judul' => $this->input->post('judul'),
                    'isi' => $this->input->post('isi'),
                    'tgl_berita' => $this->input->post('tgl_berita'),
                    'gambar' => $upload_data['uploads']['file_name']
                );

                $this->m_berita->edit($data);
                $this->session->set_flashdata('pesan', 'Data Berita Berhasil Di Edit !!');
                redirect('berita');
            }
        }
        $data = array(
            'title' => 'RTQ Al-Yusro',
            'title2' => 'Edit Data Berita',
            'berita' => $this->m_berita->detail($id),
            // 'bagian' => $this->m_bagian->lists(),
            'isi' => 'admin/berita/v_edit'
        );
        $this->load->view('admin/layout/v_wrapper', $data, FALSE);
    }

    public function delete($id)
    {
        $berita = $this->m_berita->detail($id);
        if ($berita->foto != "") {
            unlink("./foto_berita/" . $berita->foto);
        }

        $data = array('id' => $id);
        $this->m_berita->delete($data);
        $this->session->set_flashdata('pesan', 'Berita Berhasil di Hapus');
        redirect('berita');
    }
}
